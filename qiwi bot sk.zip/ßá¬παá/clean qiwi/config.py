bot_token = "1726611393:AAHKIZtXwslLn2GyhWuTgB75w2ijvzOpPQg" # @botfather

QIWI_ACCOUNT = '79622466783' #НОМЕР КИВИ КОШЕЛЬКА
QIWI_TOKEN = '437b5ea4ff9df24c26986666da78ea12' #qiwi.com/api

admin_id = '1546182461' # можно узнать в @eyegodsbot ЭТО ЦЫФРЫ. ИХ НАДО ТАКЖЕ ВСТАВИТЬ В ФАЙЛЕ data=> admin.json

oneday = 10 # ЕСЛИ МЕНЯЕТЕ ТУТ ЗНАЧЕНИЯ, МЕНЯЙТЕ И В MAIN.PY 35 СТРОКА цена за день подписки
threeday = 140 # три дня подписки
sevenday = 320 # неделя подписки