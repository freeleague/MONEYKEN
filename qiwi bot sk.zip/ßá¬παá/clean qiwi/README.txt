Язык - Python 3
Библиотеки - aiogram, qiwipy
настройки в конфиге, ничего сложного
ЗАПУСКАТЬ ДВА ФАЙЛА!
main.py balanceCheaker.py
при поддержке @Pcholken всем спасибо
